function generate_seg_train_test_file_2
    clc;clear;

    path = 'D:\Data\Environment Context\segment_data\';
    files = dir(path);
    n=length(files);
    
    tic;
    icount = 1;
    for i = 1:n
        if ~isdir(files(i).name)
            classname = files(i).name
            calGenerateTrainTestFiles(classname);
        end
    end
    toc
 figure;


function calGenerateTrainTestFiles(classname)

    % by Shi-wen Deng
    %generate the 1) segments,  2) train and test set
    % Non-overlap



    % classname = 'airport';


    addpath 'D:\Dropbox\Matlab-Toolbox\xmltree';
    addpath 'D:\Dropbox\Matlab-Toolbox\AuditoryToolbox';

    test_file_id = 3;

    %1) generate segments
    path_name = ['D:\Data\Environment Context\original_data\',classname,'\'];
    output_pathclass =  ['D:\Data\Environment Context\segment_data2\',classname, '\'];
    output_path = ['D:\Data\Environment Context\segment_data2\',classname, '\segments\'];

    files = dir([path_name,'*.wav']);
    n = length(files);


    i_train = 1;
    i_test = 1;
    for i = 1:n
        filename =[path_name,files(i).name];
        x = 0;
        fs = 0;
        filename
        [x,fs] =wavread(filename); 
        segment_len = fs * 4;  % the length of each segment is 4 s.
        file_len = min(length(x),fs*3*60);  % to sure that the length each file is less than 3 min.

        j = 1;
        j_count = 1;
        while j + segment_len <file_len 
            segment =0;
            segment = x(j:j+segment_len);
            j = j +segment_len;
            ids = sprintf('_%d.wav', j_count);
            output_filename = [output_path,'Seg_',files(i).name,ids];
            wavwrite(segment,fs,output_filename);

            if i ~=test_file_id 
                train_files(i_train).name =  output_filename;
                i_train = i_train + 1;
            else
                test_files(i_test).name = output_filename;
                i_test = i_test + 1;
            end

            j_count = j_count + 1;
        end

    end

    tree_train = struct2xml(train_files);
    save(tree_train,[output_pathclass,'trainfiles.xml']);
    tree_test = struct2xml(test_files);
    save(tree_test,[output_pathclass,'testfiles.xml']);

    %-------------------

    rmpath 'D:\Dropbox\Matlab-Toolbox\AuditoryToolbox';
    rmpath  'D:\Dropbox\Matlab-Toolbox\xmltree';

   