function [W,Mu, Sigma]=cal_LearnGMM(Data,nbStates)
%each colum is a vector

nbVar = size(Data,1);
[Priors, Mu, Sigma] = EM_init_kmeans(Data, nbStates);
[Priors, Mu, Sigma] = EM(Data, Priors, Mu, Sigma);

W=Priors;
