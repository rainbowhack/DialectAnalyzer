function [LR] = calGMM_LR(x,MU,Sigma,w)
    [N,K]=size(MU); 
    
    for k=1:K
         M=MU(:,k);
         S=Sigma(:,:,k);
         B(k,1)=gaussPDF(x, M, S);
    end

    LR=log(w*B);
