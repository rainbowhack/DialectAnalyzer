generate_seg_train_mfcc 
	read wave file and generate mfcc feature

generate_seg_train_test_file_2
	random generate train and test sets