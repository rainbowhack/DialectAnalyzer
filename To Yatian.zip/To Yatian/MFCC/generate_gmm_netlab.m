clear;clc;

classname = 'train';

%generate gmm
addpath 'D:\Dropbox\Matlab-Toolbox\Netlab';

path_name = ['D:\Data\Environment Context\segment_data\', classname, '\'];
mfcc_train = dlmread([path_name,'mfcc_train.dat']);
mfcc_train = mfcc_train';

n_in = 12;
n_centers = 10;
mix = gmm(n_in, n_centers, 'spherical');
options = foptions;
options(1) = 1; % print error values
options(14) = 500;   % number of iterations of k-means
mix = gmminit(mix, mfcc_train, options);  % with each row corresponding to a vector

% train model
options(1) = 1; % print error values
options(5) = 1; %prevent collapse of variances
options(14) = 100; % number of iterations
mix = gmmem(mix, mfcc_train, options);


%save the matlab data struct to disk by using the xml toolbox
addpath 'D:\Dropbox\Matlab-Toolbox\xmltree';
tree = struct2xml(mix);
save(tree,[path_name,'gmm.xml']);
rmpath 'D:\Dropbox\Matlab-Toolbox\xmltree';


rmpath 'D:\Dropbox\Matlab-Toolbox\Netlab';

figure;