clear;clc;
% this code will be cancel due to its poor performance.


addpath 'D:\Dropbox\Matlab-Toolbox\GMM';

path_name = 'D:\Data\Environment Context\segment_data\beach\';
mfcc_train = dlmread([path_name,'mfcc_train.dat']);

n_states = 10;
[priors, mu, sigma] = cal_LearnGMM(mfcc_train,n_states);


rmpath 'D:\Dropbox\Matlab-Toolbox\GMM';

figure;
