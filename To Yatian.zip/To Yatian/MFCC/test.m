clc;

a=0;
num=0;
cre =0;
for i = 1:n_class
    names{i} = classes(i).name;
    y(i,:) = classes(i).results;
    classid = classes(i).id;
    a(i,1) = classes(i).results(classid)/classes(i).num;
    num = num + classes(i).num;
    cre = cre + classes(i).results(classid);
end
b = cre /num
figure;
bar(y)



