clear;clc;
%generate all test files over all class

addpath 'D:\Dropbox\Matlab-Toolbox\xmltree';

path = 'D:\Data\Environment Context\segment_data2\';
xml_file = ['D:\Data\Environment Context\', 'allcs_testfiles.xml'];
delete(xml_file);

files = dir(path);
n=length(files);

% obtain the information of test data 
icount = 1;
inum = 1;
for i = 1:n
    if ~isdir(files(i).name)

        csname = files(i).name;
        xml_filename = [path, csname,'\testfiles.xml'];
        tree = xmltree(xml_filename);
        u = convert(tree);
        testfiles(icount).csname = csname;
        testfiles(icount).files = convert(tree);
        testfiles(icount).filenum = length(testfiles(icount).files.name);
        
        for j = 1:testfiles(icount).filenum
            allfiles(inum).csname = csname;
            allfiles(inum).filename = testfiles(icount).files.name(j);
            inum = inum + 1;
        end
        icount = icount +1;
    end
end

N = length(allfiles);
pos = randperm(N);
for i = 1:N
    classname = allfiles(pos(i)).csname;
    filename = cell2mat(allfiles(pos(i)).filename); 
%     filename = [path,classname,'\segments\',filename];

    alcs_testfiles(i).class = classname;
    alcs_testfiles(i).file = filename;
end
str = sprintf('Total: %d files.',N);
disp(str);

tree = struct2xml(alcs_testfiles);

save(tree, xml_file);

rmpath  'D:\Dropbox\Matlab-Toolbox\xmltree';
figure;

