clc;clear;
% by Shi-wen Deng
%generate the 1) segments,  2) train and test set, and %3) mfcc feature.

classname = 'train';

addpath 'E:\matlab\toolbox\xmltree';
addpath 'E:\matlab\toolbox\AuditoryToolbox';

%1) generate segments
path_name = ['D:\Data\Environment Context\original_data\',classname,'\'];
output_path = ['D:\Data\Environment Context\segment_data\',classname, '\segments\'];

files = dir([path_name,'*.wav']);
n = length(files);

for i = 1:n
    filename =[path_name,files(i).name];
    x = 0;
    fs = 0;
    [x,fs] =wavread(filename); 
    segment_len = fs * 4;  % the length of each segment is 4 s.
    file_len = min(length(x),fs*3*60);  % to sure that the length each file is less than 3 min.
    j = 1;
    j_count = 1;
    while j + segment_len <file_len 
        segment =0;
        segment = x(j:j+segment_len);
        j = j +segment_len;
        ids = sprintf('_%d.wav', j_count);
        output_filename = [output_path,'Seg_',files(i).name,ids];
        wavwrite(segment,fs,output_filename);
        j_count = j_count + 1;
    end
    
end


% 2) generate train set and test set
path_name = ['D:\Data\Environment Context\segment_data\',classname,'\'];
seg_path_name = [path_name,'segments\'];
files = dir([seg_path_name,'*.wav']);
n = length(files);
p = randperm(n);
train_num = round(0.75*n);

train_set = p(1:train_num);
test_set = p(train_num+1:n);

N1 = length(train_set);
for i = 1:N1
    train_files(i).name = files(train_set(i)).name;
end
N2 = length(test_set);
for i = 1:N2
    test_files(i).name = files(test_set(i)).name;
end

tree_train = struct2xml(train_files);
save(tree_train,[path_name,'trainfiles.xml']);
tree_test = struct2xml(test_files);
save(tree_test,[path_name,'testfiles.xml']);

%-------------------


% %3)generate mfcc features
% 
% path_name = ['D:\Data\Environment Context\segment_data\', classname,'\'];
% seg_path_name = [path_name,'segments\'];
% 
% % files = dir([seg_path_name,'*.wav']);
% % train_set = dlmread([path_name,'train.dat']);
% 
% tree_train = xmltree([path_name, 'trainfiles.xml']);
% trainfiles = convert(tree_train);
% 
% mfcc_train = [];
% n = length(trainfiles.name);
% for i = 1:n
%     filename = [seg_path_name, cell2mat(trainfiles.name(i))];
%     [x, fs] = wavread(filename);
%     [ceps] = mfcc(x, fs);
%     if sum(sum(isnan(ceps)))>0  %remove the columns that includes NaN data from ceps
%         [r,c] = find(isnan(ceps)>0);
%         c = unique(c);
%         ceps(:,c) = [];
%     end
%     mfcc_train = [mfcc_train, ceps(2:13,:)];
% end
% dlmwrite([path_name,'mfcc_train.dat'],mfcc_train);



rmpath 'D:\Dropbox\Matlab-Toolbox\AuditoryToolbox';
rmpath  'D:\Dropbox\Matlab-Toolbox\xmltree';

figure;